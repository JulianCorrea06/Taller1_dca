	package correa_juliandavid_Taller1;
	import processing.core.PApplet;

	public class Nave {
		
		protected int etapa;
		protected PApplet app;
		protected float x;
		protected float y;
		int xc = 300;
		int yc = 200;
		protected boolean etapaPasar = false;

		

		
		public Nave(PApplet app) {
			this.app = app;
			
			
		}
	
		
		public void pintar() {
		//pintarNave
			
			app.noStroke();
			app.fill(54,0,99);
			app.rect(xc, yc, 80, 140);
			app.fill(344,90,90);
			app.triangle(xc, yc, xc+40, yc-40, xc+80, yc);
			app.fill(191,58,96);
			app.ellipse(xc+40, yc+40, 40, 40);
			app.ellipse(xc+40, yc+100, 40, 40);
			app.fill(191,0,0);
			app.rect(xc+20, yc+140, 40, 20);
			app.fill(50,70,97);
			app.rect(xc+20, yc+160, 40, 40);
			app.fill(36,75,97);
			app.rect(xc+20, yc+160, 40, 20);
			
			yc=yc-5;
			
			}
		public void pintarQuieto() {
			app.noStroke();
			app.fill(54,0,99);
			app.rect(xc, yc, 80, 140);
			app.fill(344,90,90);
			app.triangle(xc, yc, xc+40, yc-40, xc+80, yc);
			app.fill(191,58,96);
			app.ellipse(xc+40, yc+40, 40, 40);
			app.ellipse(xc+40, yc+100, 40, 40);
			app.fill(191,0,0);
			app.rect(xc+20, yc+140, 40, 20);
			app.fill(50,70,97);
			app.rect(xc+20, yc+160, 40, 40);
			app.fill(36,75,97);
			app.rect(xc+20, yc+160, 40, 20);
		}
		}
	

