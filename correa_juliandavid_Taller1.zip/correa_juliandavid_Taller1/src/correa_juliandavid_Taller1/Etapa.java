package correa_juliandavid_Taller1;

import processing.core.PApplet;

public class Etapa {
	
	protected int etapa;
	protected PApplet app;
	protected float x;
	protected float y;
	protected boolean etapaPasar = false;

	

	
	public Etapa(PApplet app) {
		this.app = app;
		
		
	}
	
	public void pintar() {
		//pintar Capsula
		app.noFill();
		app.stroke(354,0,100);
		app.rect(1005, 300, 80, 150, 18, 18, 18, 18);
		//pintar asteroide
		app.fill(214,23,59,100);
		app.noStroke();
		app.ellipse(1060, 600, 400, 400);
		app.fill(214,30,46,100);
		app.ellipse(1000, 620, 150, 150);
		app.fill(214,30,46,100);
		app.ellipse(1120, 500, 100, 100);
		
		//pintar rosa
		app.fill(122,83,71);
		app.noStroke();
		app.rect(1041, 355, 10, 50);
		app.fill(344,90,90);
		app.ellipse(1046, 345, 50, 50);
		
		//pintar sol
		app.fill(50,70,97);
		app.ellipse(50, 50, 400, 400);
		
		//pintar Estrella
		int x =150;
		int y =500;
		app.stroke(54,0,99);
		app.line(x,y,x+11*2,y+19*2);
		app.line(x+11*2,y+19*2,x+33*2,y+25*2);
		app.line(x+33*2,y+25*2,x+19*2,y+42*2);
		app.line(x+19*2,y+42*2,x+21*2,y+64*2);
		app.line(x+21*2,y+64*2,x,y+55*2);
		app.line(x,y,x-11*2,y+19*2);
		app.line(x-11*2,y+19*2,x-33*2,y+25*2);
		app.line(x-33*2,y+25*2,x-19*2,y+42*2);
		app.line(x-19*2,y+42*2,x-21*2,y+64*2);
		app.line(x-21*2,y+64*2,x,y+55*2);
		
		//pintar Cohete
		int xc = 300;
		int yc = 200;
		app.noStroke();
		app.fill(54,0,99);
		app.rect(xc, yc, 80, 140);
		app.fill(344,90,90);
		app.triangle(xc, yc, xc+40, yc-40, xc+80, yc);
		app.fill(191,58,96);
		app.ellipse(xc+40, yc+40, 40, 40);
		app.ellipse(xc+40, yc+100, 40, 40);
		app.fill(191,0,0);
		app.rect(xc+20, yc+140, 40, 20);
		app.fill(50,70,97);
		app.rect(xc+20, yc+160, 40, 40);
		app.fill(36,75,97);
		app.rect(xc+20, yc+160, 40, 20);
		
		//pintar luna
		int xl = 550;
		int yl =100;
		app.stroke(54,0,99);
		app.fill(182,49,88);
		
		//app.rotate((float) (app.PI/2));
		app.arc(xl, yl, 150, 150,app.PI*(1/2), app.PI);
		app.noFill();
		app.arc(xl+200, yl, 150, 150,app.PI*(1/2), app.PI,app.CHORD);
		
		//Pintar Space
		int xt = 950;
		int yt = 100;
		app.fill(54,0,99);
		app.textSize(64);
		app.text("SPACE",xt,yt);
	/*	
		//Pintar Saturno
		int xs=600;
		int ys=500;
		
		
		app.fill(26,87,83);
		app.noStroke();
		app.ellipse(xs, ys, 150, 150);
		//pintar Roquitas
		
		for(int i = 0; i<6;i++ ) {
			app.ellipse(xs-80, ys-80, 30, 30);
			app.ellipse(xs-120, ys-100, 30, 30);
			app.ellipse(xs-120, ys+100, 30, 30);
			app.ellipse(xs-120, ys+30, 30, 30);
			app.ellipse(xs-150, ys, 30, 30);
			app.ellipse(xs-120, ys-30, 30, 30);
		}
				
	*/
		
		
		
		
	}
	
	
}
