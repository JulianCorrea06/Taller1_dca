package correa_juliandavid_Taller1;

import processing.core.PApplet;

public class Constelacion {

	protected int etapa;
	protected PApplet app;
	protected float x;
	protected float y;
	protected boolean luz1 = false;
	protected boolean luz2 = false;
	protected boolean luz3 = false;
	protected boolean luz4 = false;
	protected boolean luz5 = false;

	public Constelacion(PApplet app) {
		this.app = app;
	}
	
	public void pintarLuz1() {
		app.fill(359, 0, 99);
		app.ellipse(149, 497, 14, 14);
	}

	public void pintarLuz2() {
		app.fill(359, 0, 99);
		app.ellipse(219, 547, 14, 14);
	}

	public void pintarLuz3() {
		app.fill(359, 0, 99);
		app.ellipse(194, 628, 14, 14);
	}

	public void pintarLuz4() {
		app.fill(359, 0, 99);
		app.ellipse(107, 628, 14, 14);
	}

	public void pintarLuz5() {
		app.fill(359, 0, 99);
		app.ellipse(83, 549, 14, 14);
	}

}

