package correa_juliandavid_Taller1;

import processing.core.PApplet;

public class Main extends PApplet {
	int pantalla = 0;
	private Logica log;
	
	public static void main(String[] args) {
		PApplet.main("correa_juliandavid_Taller1.Main");;
		
		
	}
	
	public void settings() {
		size(1200,700);		
	}
	
	public void setup() {
		colorMode(HSB, 360, 100 ,100,100);
		log = new Logica(this);
	}
	
	public void draw() {
		/* Se hace un switch para ir cambiando de pantalla, cada pantalla es una interacci�n que el usuario tiene que realizar.
		 * El documento txt cambia algo por cada interaccion completada. Pero solo hay 7 que se distingan entre s�.*/
		switch(pantalla) {
		
		case 0: //Dibuja toda la interfaz, pero solo se puede interactuar con la rosa.
		log.dibujar1();
		break;
		
		case 1://Quita la capsula de la rosa. La siguiente interaccion es click al sol.
		log.interaccion1();
		log.dibujar2();
		fill(0,11,99);
		textSize(30);
		text("Completa al sol", 20,670);
		noFill();
		break;
		
		case 2://Click al sol de nuevo
		log.dibujarSol1();
		break;
		
		case 3://Dibuja el sol completo, la siguiente interacci�n es presionar barra espaciadora.
		log.dibujarSol2();
		break;
		
		case 4://Dibuja a la nave en movimiento, la siguiente interacci�n es clickear la punta mas alta de la estrella.
		log.interaccion2();
		log.dibujarSol2();
		log.dibujarNave();
		
		break;
		
		case 5://Dibuja un circulo en la punta de la estrella
			log.interaccion3();
			log.dibujarSol2();
			log.dibujarNave();
			log.dibujarConstelacion1();
		break;
		
		case 6://Dibuja un circulo en la punta de la estrella 2
			log.dibujarSol2();
			log.dibujarNave();
			log.dibujarConstelacion1();
			log.dibujarConstelacion2();
		break;
		
		case 7://Dibuja un circulo en la punta de la estrella 3
			log.dibujarSol2();
			log.dibujarNave();
			log.dibujarConstelacion1();
			log.dibujarConstelacion2();
			log.dibujarConstelacion3();
		break;
		
		case 8://Dibuja un circulo en la punta de la estrella 4
			log.dibujarSol2();
			log.dibujarNave();
			log.dibujarConstelacion1();
			log.dibujarConstelacion2();
			log.dibujarConstelacion3();
			log.dibujarConstelacion4();
		break;
		
		case 9://Dibuja un circulo en la punta de la estrella 5, la siguiente interacci�n es mover el cursor del mouse para que la luna quede en su lugar.
			log.interaccion4();
			log.dibujarSol2();
			log.dibujarNave();
			log.dibujarConstelacion1();
			log.dibujarConstelacion2();
			log.dibujarConstelacion3();
			log.dibujarConstelacion4();
			log.dibujarConstelacion5();
			
			if(log.arrastrarLuna()==true) {
				log.dibujarLunaArrastrar();
			}else {
				log.dibujarLuna();
			}
			
			if((log.arrastrarLuna()==true)&&mouseX >= 750) {
				pantalla++;
			}
		break;
		
		case 10://Coloca la luna en su lugar, la siguiente interaccion es escribir con el teclado la palabra "space".
			log.interaccion5();
			log.dibujarSol2();
			log.dibujarNave();
			log.dibujarConstelacion1();
			log.dibujarConstelacion2();
			log.dibujarConstelacion3();
			log.dibujarConstelacion4();
			log.dibujarConstelacion5();
			log.dibujarLunaFin();
		break;
		
		case 11://Borra del lienzo la letra S cuando el usuario la escribe
			log.dibujarSol2();
			log.dibujarNave();
			log.dibujarConstelacion1();
			log.dibujarConstelacion2();
			log.dibujarConstelacion3();
			log.dibujarConstelacion4();
			log.dibujarConstelacion5();
			log.dibujarLunaFin();
			log.dibujarEspacio1();
			log.interaccion5();
		break;
		case 12://Borra del lienzo la letra P cuando el usuario la escribe
			log.dibujarSol2();
			log.dibujarNave();
			log.dibujarConstelacion1();
			log.dibujarConstelacion2();
			log.dibujarConstelacion3();
			log.dibujarConstelacion4();
			log.dibujarConstelacion5();
			log.dibujarLunaFin();
			log.dibujarEspacio1();
			log.dibujarEspacio2();
		break;
		case 13://Borra del lienzo la letra A cuando el usuario la escribe
			log.dibujarSol2();
			log.dibujarNave();
			log.dibujarConstelacion1();
			log.dibujarConstelacion2();
			log.dibujarConstelacion3();
			log.dibujarConstelacion4();
			log.dibujarConstelacion5();
			log.dibujarLunaFin();
			log.dibujarEspacio1();
			log.dibujarEspacio2();
			log.dibujarEspacio3();
			
		break;
		case 14://Borra del lienzo la letra C cuando el usuario la escribe
			log.dibujarSol2();
			log.dibujarNave();
			log.dibujarConstelacion1();
			log.dibujarConstelacion2();
			log.dibujarConstelacion3();
			log.dibujarConstelacion4();
			log.dibujarConstelacion5();
			log.dibujarLunaFin();
			log.dibujarEspacio1();
			log.dibujarEspacio2();
			log.dibujarEspacio3();
			log.dibujarEspacio4();
		break;
		case 15://Borra del lienzo la letra E cuando el usuario la escribe, la siguiente consiste en presionar la tecla ENTER para generar peque�as estrellas en el lienzo.
			log.interaccion6();
			log.dibujarSol2();
			log.dibujarNave();
			log.dibujarConstelacion1();
			log.dibujarConstelacion2();
			log.dibujarConstelacion3();
			log.dibujarConstelacion4();
			log.dibujarConstelacion5();
			log.dibujarLunaFin();
			log.dibujarEspacio5();
		break;
		case 16://Aparece la pantalla que dice que ganaste el juego.
			log.interaccion7();
			background(359,0,99);
			fill(359,0,5);
			text("GANASTE",500, height/2);
			noFill();
		break;
		}
	}
	
	public void mousePressed() {
		switch(pantalla) {
		case 0:
		frameCount = 0; 
		if(log.click1() == true ) {
		log.click1();
		pantalla++;
		}
		break;
		
		case 1:
			if(log.click2()==true) {
			pantalla++;
			}
		break;
		case 2:
			if(log.click2()==true) {
			pantalla++;
			}
		break;
		
		case 4:
			if(log.clickConstelacion1()==true) {
				pantalla++;
			}
		break;
		
		case 5:
			if(log.clickConstelacion2()==true) {
				pantalla++;
			}
		break;
		
		case 6:
			if(log.clickConstelacion3()==true) {
				pantalla++;
			}
		break;
		
		case 7:
			if(log.clickConstelacion4()==true) {
				pantalla++;
			}
		break;
		
		case 8:
			if(log.clickConstelacion5()==true) {
				pantalla++;
			}
		break;
		
		
		
		}
	}
	
	
	
	
	public void mouseDragged() {
		
	}

	public void keyPressed() {
		switch (pantalla) {

		case 3:
			if (log.teclear() == true) {
				pantalla++;
			}

			break;
		
		case 10:
			if(log.spaceTec1()==true) {
				pantalla++;
			}
		break;
		case 11:
			if(log.spaceTec2()==true) {
				pantalla++;
			}
		break;

		case 12:
			if(log.spaceTec3()==true) {
				pantalla++;
			}
		break;
		case 13:
			if(log.spaceTec4()==true) {
				pantalla++;
			}
		break;
		case 14:
			if(log.spaceTec5()==true) {
				pantalla++;
			}
		break;
		case 15:
		 log.teclearEstrella();
		if(log.agregarEstrella()==10) {
			pantalla++;
		}
		break;
		}
	}
}
