package correa_juliandavid_Taller1;

import processing.core.PApplet;

public class Estrella {

	private PApplet app;
	private int x;
	private int y; 
	private int tam;
	
	public Estrella (PApplet app) {
		this.app = app;
		x = (int) app.random(0,1200);
		y = (int) app.random(0,700);
		tam = 20;
	}
	
	public void pintar() {
		
		app.fill(359,0,99);
		app.ellipse(x,y,20,20);
	}
	
	
}
