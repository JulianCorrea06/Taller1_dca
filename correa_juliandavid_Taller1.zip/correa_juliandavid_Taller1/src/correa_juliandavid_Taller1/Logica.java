package correa_juliandavid_Taller1;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;

import processing.core.PApplet;

public class Logica {

	private PApplet app;
	private Etapa e;
	private Sol s;
	private Nave n;
	private String[] texto;
	private Constelacion c;
	private Luna l;
	private int indice;
	private ArrayList<Estrella> estrellas;
	private String[] palabrasTexto;
	


	public Logica(PApplet app) {
		this.app = app;
		e = new Etapa(app);
		s = new Sol(app);
		n = new Nave(app);
		c = new Constelacion(app);
		l = new Luna(app);
		estrellas = new ArrayList <Estrella>();
		texto = app.loadStrings("Principito.txt");
		dividirPalabras();
		//cargarTXT();
	
	}
	
	//Separamos las palabras por el espacio
	public void dividirPalabras() {
		palabrasTexto = PApplet.splitTokens(texto[0]);
	}
		
	//Interacciones con el Txt
	//La primera interaccion es tocar la capsula de la rosa, este metodo es llamado en el main, para que con el cambio gr�fico, se cambie el txt.
	public void interaccion1() {
		for(int i = 0; i < palabrasTexto.length; i++) {
			char[] letras = palabrasTexto[i].toCharArray();
			for(int j =0; j<letras.length;j++) {
				if(letras[j] == '4') {
					letras[j] = 'p';
				}
			}
			palabrasTexto[i] = new String(letras);
		}
		
		escribirNewTexto();
	}
	//Todos las interacciones est�n explicadas en el main.
	public void interaccion2() {

				for(int i = 0; i < palabrasTexto.length; i++) {
					char[] letras = palabrasTexto[i].toCharArray();
					for(int j =0; j<letras.length;j++) {
						if(letras[j] == '7') {
							letras[j] = 'a';
						}
					}
					palabrasTexto[i] = new String(letras);
				}
				escribirNewTexto();
				
			}
	public void interaccion3() {
		
				for(int i = 0; i < palabrasTexto.length; i++) {
					char[] letras = palabrasTexto[i].toCharArray();
					for(int j =0; j<letras.length;j++) {
						if(letras[j] == '8') {
							letras[j] = 'c';
						}
					}
					palabrasTexto[i] = new String(letras);
				}
				
				escribirNewTexto();
			}
	public void interaccion4() {
		
		for(int i = 0; i < palabrasTexto.length; i++) {
			char[] letras = palabrasTexto[i].toCharArray();
			for(int j =0; j<letras.length;j++) {
				if(letras[j] == '$') {
					letras[j] = 'l';
				}
			}
			palabrasTexto[i] = new String(letras);
		}
		escribirNewTexto();
		
	}
public void interaccion5() {
		
		for(int i = 0; i < palabrasTexto.length; i++) {
			char[] letras = palabrasTexto[i].toCharArray();
			for(int j =0; j<letras.length;j++) {
				if(letras[j] == '!') {
					letras[j] = 'e';
				}
			}
			palabrasTexto[i] = new String(letras);
		}
		escribirNewTexto();
		
	}
public void interaccion6() {
	
	for(int i = 0; i < palabrasTexto.length; i++) {
		char[] letras = palabrasTexto[i].toCharArray();
		for(int j =0; j<letras.length;j++) {
			if(letras[j] == '&') {
				letras[j] = 's';
			}
		}
		palabrasTexto[i] = new String(letras);
	}
	escribirNewTexto();
}
public void interaccion7() {
	
	for(int i = 0; i < palabrasTexto.length; i++) {
		char[] letras = palabrasTexto[i].toCharArray();
		for(int j =0; j<letras.length;j++) {
			if(letras[j] == '%') {
				letras[j] = 't';
			}
		}
		palabrasTexto[i] = new String(letras);
	}
	escribirNewTexto();
}
	
	private void escribirNewTexto() {
		String temp = PApplet.join(palabrasTexto, " ");
		try {
			File archivo = new File("texto.txt");
			archivo.createNewFile();
			BufferedWriter bw = new BufferedWriter(new FileWriter(archivo));
			bw.write(temp);
			bw.flush();
			bw.close();
		} catch (Exception e) {
			
		}
	}
	// Dibujar
	public void dibujar1() {
		app.background(214, 47, 20, 100);
		e.pintar();

		app.fill(0, 11, 99);
		app.textSize(30);
		app.text("Libera a la rosa encapsulada", 20, 670);
		app.noFill();
	}

	public void dibujar2() {
		app.background(214, 47, 20, 100);
		s.pintar();
		app.fill(0, 11, 99);
		app.textSize(30);
		app.text("Completa al sol", 20, 670);
		app.noFill();
	}

	public void dibujarSol1() {
		app.background(214, 47, 20, 100);
		s.pintar();
		app.fill(44, 66, 91);
		app.ellipse(30, 30, 350, 350);
		app.noFill();
		app.fill(0, 11, 99);
		app.textSize(30);
		app.text("Completa al sol", 20, 670);
		app.noFill();

	}

	public void dibujarSol2() {
		app.background(214, 47, 20, 100);
		s.pintar();
		app.fill(44, 66, 91);
		app.ellipse(30, 30, 350, 350);
		app.noFill();
		app.fill(30, 82, 92);
		app.ellipse(10, 10, 150, 150);
		app.fill(0, 11, 99);
		app.textSize(30);
		app.text("La tecla mas larga del teclado har� despegar la nave", 20, 670);
		app.noFill();

	}

	public void dibujarNave() {
		// tapar figuras anteriores
		app.fill(214, 47, 20, 100);
		app.rect(0, 630, 823, 700);
		app.rect(270, 141, 150, 350);
		app.noFill();
		// pintar la nave y el texto
		n.pintar();
		app.fill(0, 11, 99);
		app.textSize(25);
		app.text("Toca la punta m�s alta de la estrella", 20, 670);
		app.noFill();
	}

	public void dibujarConstelacion1() {
		app.fill(214, 47, 20, 100);
		app.rect(0, 630, 823, 700);
		app.noFill();
		c.pintarLuz1();

		app.fill(0, 11, 99);
		app.textSize(30);
		app.text("Tocas las puntas de estrella empezando por la derecha", 20, 670);
		app.noFill();
	}

	public void dibujarConstelacion2() {
		app.fill(214, 47, 20, 100);
		app.rect(0, 630, 823, 700);
		app.noFill();
		c.pintarLuz2();

		app.fill(0, 11, 99);
		app.textSize(30);
		app.text("Completa la constelaci�n estrella", 20, 670);
		app.noFill();
	}

	public void dibujarConstelacion3() {
		app.fill(214, 47, 20, 100);
		app.rect(0, 630, 823, 700);
		app.noFill();
		c.pintarLuz3();

		app.fill(0, 11, 99);
		app.textSize(30);
		app.text("Completa la constelaci�n estrella", 20, 670);
		app.noFill();
	}

	public void dibujarConstelacion4() {
		app.fill(214, 47, 20, 100);
		app.rect(0, 630, 823, 700);
		app.noFill();
		c.pintarLuz4();

		app.fill(0, 11, 99);
		app.textSize(30);
		app.text("Completa la constelaci�n estrella", 20, 670);
		app.noFill();
	}

	public void dibujarConstelacion5() {
		app.fill(214, 47, 20, 100);
		app.rect(0, 630, 823, 700);
		app.noFill();
		c.pintarLuz5();

		app.fill(0, 11, 99);
		app.textSize(30);
		app.text("Completa la constelaci�n estrella", 20, 670);
		app.noFill();
	}
	
	public void dibujarLuna() {
		l.pintarLuna();
		app.fill(214, 47, 20, 100);
		app.noStroke();
		app.rect(0, 630, 823, 700);
		app.noFill();
		app.fill(0, 11, 99);
		app.textSize(30);
		app.text("Pon la luna azul en su lugar", 20, 670);
		app.noFill();
	}
	
	public void dibujarLunaArrastrar() {
		l.pintarLunaArrastrar();
		app.fill(214, 47, 20, 100);
		app.noStroke();
		app.rect(0, 630, 823, 700);
		app.noFill();
		app.fill(0, 11, 99);
		app.textSize(30);
		app.text("Ya casi", 20, 670);
		app.noFill();
		
	}
	public void dibujarLunaFin() {
		l.pintarLunaFin();
		app.fill(214, 47, 20, 100);
		app.noStroke();
		app.rect(0, 630, 823, 700);
		app.noFill();
		app.fill(0, 11, 99);
		app.textSize(30);
		app.text("Escribe espacio en ingl�s", 20, 670);
		app.noFill();
	}
	public void dibujarEspacio1() {
		l.pintarLunaFin();
		app.fill(214, 47, 20, 100);
		app.noStroke();
		app.rect(0, 630, 823, 700);
		app.fill(214, 47, 20, 100);
		app.noStroke();
		app.rect(945, 45, 40, 60);
		app.noFill();
		app.fill(0, 11, 99);
		app.textSize(30);
		app.text("Escribe espacio en ingl�s", 20, 670);
		app.noFill();
	}
	public void dibujarEspacio2() {
		dibujarEspacio1();
		app.fill(214, 47, 20, 100);
		app.noStroke();
		app.rect(986, 45, 40, 60);
		app.noFill();
	}
	public void dibujarEspacio3() {
		dibujarEspacio2();
		app.fill(214, 47, 20, 100);
		app.noStroke();
		app.rect(1020, 45, 46, 60);
		app.noFill();
	}
	public void dibujarEspacio4() {
		dibujarEspacio3();
		app.fill(214, 47, 20, 100);
		app.noStroke();
		app.rect(1065, 45, 46, 60);
		app.noFill();
	}
	public void dibujarEspacio5() {
		dibujarEspacio3();
		app.fill(214, 47, 20, 100);
		app.noStroke();
		app.rect(920, 36, 300, 200);
		app.noFill();
		app.fill(214, 47, 20, 100);
		app.noStroke();
		app.rect(0, 630, 823, 700);
		app.fill(0, 11, 99);
		app.textSize(30);
		app.text("Presiona Enter para generar estrellas", 20, 670);
		app.noFill();
		
		for(int i= 0; i < estrellas.size();i++) {
			Estrella z = estrellas.get(i);
			z.pintar();	
		}	
	}

	// metodos de clickeo
	public boolean click1() {

		if (app.mouseX > 1005 && app.mouseX < 1085 && app.mouseY > 300 && app.mouseY < 450) {
			return true;
		}
		return false;

	}

	public boolean click2() {
		if (app.mouseX > 0 && app.mouseX < 255 && app.mouseY > 0 && app.mouseY < 245) {
			return true;
		}
		return false;
	}

	public boolean clickConstelacion1() {
		if (app.mouseX > 142-5 && app.mouseX < 156+5 && app.mouseY > 486-5 && app.mouseY < 507+5) {
			return true;
		}
		return false;
	}

	public boolean clickConstelacion2() {
		if (app.mouseX > 212-5 && app.mouseX < 212 + 19 && app.mouseY > 542-5 && app.mouseY < 542 + 19) {
			return true;
		}
		return false;
	}

	public boolean clickConstelacion3() {
		if (app.mouseX > 187-5 && app.mouseX < 187 + 19 && app.mouseY > 622-5 && app.mouseY < 622 + 19) {
			return true;
		}
		return false;
	}

	public boolean clickConstelacion4() {
		if (app.mouseX > 102-5 && app.mouseX < 102 + 15 && app.mouseY > 622-5 && app.mouseY < 622 + 15) {
			return true;
		}
		return false;
	}
	public boolean clickConstelacion5() {
		if (app.mouseX > 78-5 && app.mouseX < 78 + 15 && app.mouseY > 544-5 && app.mouseY < 544 + 15) {
			return true;
		}
		return false;
	}

	public boolean arrastrarLuna() {
		if(app.mouseX >550 &&app.mouseX <1200 && app.mouseY >100 &&app.mouseY < 150  ){
			return true;
		}
		return false;
	}

	public boolean teclear() {
		if (app.keyCode == ' ') {
			return true;
		}
		return false;

	}
	public boolean spaceTec1() {
		if(app.keyCode == 's'||app.keyCode == 'S') {
			return true;
		}return false;
	}
	public boolean spaceTec2() {
		if(app.keyCode == 'p'||app.keyCode == 'P') {
			return true;
		}return false;
	}
	public boolean spaceTec3() {
		if(app.keyCode == 'a'||app.keyCode == 'A') {
			return true;
		}return false;
	}
	public boolean spaceTec4() {
		if(app.keyCode == 'c'||app.keyCode == 'C') {
			return true;
		}return false;
	}
	public boolean spaceTec5() {
		if(app.keyCode == 'e'||app.keyCode == 'E') {
			return true;
		}return false;
	}
	public void teclearEstrella() {
		if(app.keyCode == app.ENTER) {
			estrellas.add(new Estrella(app));
			indice ++;
			
		}
	}
	public int agregarEstrella() {
		return indice;
	
	}
	
}
