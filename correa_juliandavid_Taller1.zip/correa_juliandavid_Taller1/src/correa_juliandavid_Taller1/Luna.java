package correa_juliandavid_Taller1;
import processing.core.PApplet;

public class Luna {

	private PApplet app;
	private float x =550;
	private float y =100;
	
	public Luna(PApplet app) {
		this.app = app;
		
	}
	
	public void pintarLuna() {
		
		app.fill(214, 47, 20, 100);
		app.rect(530, 80, 200, 200);
		app.noFill();
		int xl = 550;
		int yl =100;
		app.stroke(54,0,99);
		app.fill(182,49,88);
		
		//app.rotate((float) (app.PI/2));
		app.arc(x, y, 150, 150,app.PI*(1/2), app.PI);
		app.noFill();
		app.arc(xl+200, yl, 150, 150,app.PI*(1/2), app.PI,app.CHORD);
		
	}
	public void pintarLunaFin() {
		app.fill(214, 47, 20, 100);
		app.rect(450, 80, 200, 200);
		app.noFill();
		int xl = 550;
		int yl =100;
		app.stroke(54,0,99);
		app.fill(182,49,88);
		
		//app.rotate((float) (app.PI/2));
		app.arc(xl +200, yl, 150, 150,app.PI*(1/2), app.PI);
		app.noFill();
		
	}
	


	public void pintarLunaArrastrar() {
		//if((app.mouseButton = app.LEFT)&& (app.mouseX >550 &&app.mouseX <700 && app.mouseY >100 &&app.mouseY < 150  )) {
		app.fill(214, 47, 20, 100);
		app.rect(450, 80, 200, 200);
		app.noFill();
		int xl = 550;
		int yl =100;
		app.stroke(54,0,99);
		app.fill(182,49,88);
		
		//app.rotate((float) (app.PI/2));
		app.arc(app.mouseX, y, 150, 150,app.PI*(1/2), app.PI);
		app.noFill();
		app.arc(xl+200, yl, 150, 150,app.PI*(1/2), app.PI,app.CHORD);
	}
	
	
}
